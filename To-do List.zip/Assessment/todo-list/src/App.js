import React from 'react';
import { useState } from "react";
import './App.css';


function App() {

  const [todo, setTodo] = useState([]);
  const [check, setCheck] = useState([]);
  const [enter, setEnter] = useState("");

//function to submit the todo item from type field. 
  const submitting = (e) => {
   e.preventDefault();
    if (enter === "") {
      alert("Enter a valid todo item to submit");
      return;
    }
    setTodo([...todo, enter]);
    setEnter("");
  };

//function to create the list of all the check market items. 
    const change = (e) => {
    const { value, checked } = e.target;
    if (checked) {
      setCheck([...check, value]);
    } else {
      setCheck(check.filter((e) => e !== value));
    }
  };

//function to deleted the check marked items from the to-do list  
const deleting = () => {
  const result = todo.filter((elem, index) => {
    if (check.includes(String(index)) === false) {
      return elem;
    }
  });
  setTodo(result);
  setCheck([]);
};

  return (
    <div className="Container">
      <div className="Contain">
        TodoList
        <span>
          {/* takes input from user as todo item */}
          <input
            type="text"
            placeholder="Enter the to-do item"
            value={enter}
            onChange={(e) => setEnter(e.target.value)}
          />
          {/* submit button is used to submit the todo item into the list of todos */}
          <button type="submit" value={todo} onClick={(e) => submitting(e)}>
          Submit
          </button>
        </span>
        <div>
        <ol>
          {/* mapping the array of todo items to print the items in form of list */}
          {todo.map((elem, index) => {
            return (
                <li id="strange" key={index}>
                  {elem}{" "}
                  <input
                  type="checkbox"
                  key={index}
                  checked={elem.isChecked}
                  value={index}
                  onClick={(e) => change(e)}
                />
                </li>
            );
          })}
          </ol>
          </div>
        {/* to display the delete button only if the todo list has an item in it */}
        <span>{todo.length !== 0 && <button onClick={deleting}> Delete</button>}</span>
      </div>
    </div>
  );
}

export default App;



