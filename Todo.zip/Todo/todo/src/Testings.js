// let arr=[[1,2],[3,[4,[7,[0,9]]]],[5,6],[7,8]];
// console.log([].concat(...arr));
// console.log(arr.flat(2))

// function arrs(arr,depth){
//     while(depth>0){
//         arr=[].concat(...arr);
//         depth--;
//     }
//     return arr;
// }

// console.log(arrs(arr,4))



// function add(a){
// return a+5;
// }

// function sub(a){
// return a-2;}

// function mul(a){
// return a*4;}

// const compose=(...functions)=>{
// return (args)=>{
// return functions.reduceRight((arg,fn)=>fn(arg),args);
// }}

// const evaluating=compose(add,sub,mul);
// console.log(evaluating(5));




// let arr3=[2,4];
// console.log(arr3.reduce((prev,curr)=>{return (prev/curr)}));


// const promiseall=(promises)=>{
//     let result=[];
//     return new Promise ((resolve,reject)=>{
//         promises.forEach((p,index)=>{
//             p.then((res)=>{result.push(res);
//             if(index === promiseall.length-1){
//                 resolve(result);
//             }}).catch((err)=>{reject(err)})
//         })
//     });
// }


// promiseall([
//     Promise.resolve("hi"),
//     Promise.resolve("Hello"),
//     Promise.reject("Nothing")
// ]).then((value)=>console.log(value));


console.log("Hi");

const something=(message,cb)=>{
    setTimeout(()=>{cb(message)},2000);
}

something("How are you!", function (mess){console.log("hello this is a message " +mess)});


console.log("Hello");