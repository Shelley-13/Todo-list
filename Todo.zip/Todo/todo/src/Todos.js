import React,{useState} from 'react'

export default function Todos() {
    
    const [initial,final]=useState("");
    const [arr,setArr]=useState([]);

    function adding(){
        // setArr([...arr, initial]);
        // console.log(arr);d
        setArr((arr)=>{
            const newArr=[...arr, initial];
            console.log(newArr);
            final('');
            return newArr
        })
        }

    function remove(i){
        const some= arr.filter((id)=>{return i!==id});
        arr(some);
    }

  return (
    <>
        <label>Enter the todo item:</label>
        <input id="typing" type="text" name="enter" value={initial} onChange={(e)=>final(e.target.value)}></input>
        <button onClick={adding}>Add</button>
        <p>Here is your list{":)"}</p>
            {
                arr.length>=1 && arr.map((item, i)=> 
                {return (
                <> 
                <p key={i}>
                    <div>{item}</div>
                    <button onClick={()=>remove(i)}>Remove</button>
                    </p>
                </>)})}
    </>
  )
}